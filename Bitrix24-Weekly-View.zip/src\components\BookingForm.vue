<script setup lang="ts">
import { onMounted, ref } from 'vue'
import { bookingService } from '../services/bookingService'
import { slotService, type TimeSlot } from '../services/slotService'
import { bitrix24Api } from '../services/bitrix24Api'
import { resourceService } from '../services/resourceService'
import type { Resource } from '../models/resource.model'

const props = defineProps<{
  mode: 'create' | 'edit'
  bookingId?: string
  resourceId?: string | number
  date?: string
}>()

const loading = ref(true)
const saving = ref(false)

const form = ref({
  date: '',
  resources: [] as number[],
  leadName: '',
  clientId: null as number | null,
  phone: '',
  email: '',
  ages: ['', '', '', ''],
  slot: ''
})

const resources = ref<Resource[]>([])
const slots = ref<TimeSlot[]>([])

const loadResources = async (allowDefault: boolean) => {
  resources.value = await resourceService.getActiveResources()
  if (allowDefault && form.value.resources.length === 0 && resources.value.length > 0) {
    form.value.resources = [resources.value[0].id]
  }
}

onMounted(async () => {
  // Do NOT access window.top in a Bitrix iframe (cross-origin). The slider controls sizing.
  // A best-effort fit keeps the iframe content sized correctly.
  void bitrix24Api.fitWindow()

  try {
    if (props.mode === 'create') {
      if (props.date) {
        form.value.date = String(props.date)
      }
      if (props.resourceId !== undefined && props.resourceId !== null && String(props.resourceId).length > 0) {
        const parsed = Number(props.resourceId)
        if (!Number.isNaN(parsed)) {
          form.value.resources = [parsed]
        }
      }
    }

    await loadResources(props.mode === 'create')

    if (props.mode === 'edit' && props.bookingId && props.bookingId !== 'undefined') {
      const booking = await bookingService.getBooking(props.bookingId)
      const bookingDate = booking.DATE_FROM ?? booking.dateFrom ?? booking.date
      const dateValue = bookingDate ? new Date(bookingDate).toISOString().split('T')[0] : ''
      form.value.date = dateValue

      const bookingResources = booking.RESOURCE_IDS ?? booking.resourceIds ?? booking.resources
      if (Array.isArray(bookingResources)) {
        form.value.resources = bookingResources.map((id: string | number) => Number(id))
      } else if (booking.RESOURCE_ID ?? booking.resourceId) {
        form.value.resources = [Number(booking.RESOURCE_ID ?? booking.resourceId)]
      }

      const startTime = booking.DATE_FROM ?? booking.dateFrom
      if (startTime) {
        const timeValue = new Date(startTime).toISOString().split('T')[1]?.slice(0, 5)
        if (timeValue) {
          form.value.slot = timeValue
        }
      }

      form.value.leadName = booking.CLIENT_NAME ?? booking.client?.name ?? ''
      form.value.phone = booking.CLIENT_PHONE ?? booking.client?.phone ?? ''
      form.value.email = booking.CLIENT_EMAIL ?? booking.client?.email ?? ''
      form.value.clientId = booking.CLIENT_ID ? Number(booking.CLIENT_ID) : form.value.clientId
    }

    if (form.value.date && form.value.resources.length > 0) {
      await loadSlots()
    }
  } finally {
    loading.value = false
  }
})

const loadSlots = async () => {
  if (!form.value.date || form.value.resources.length === 0) {
    slots.value = []
    return
  }

  const dateValue = new Date(form.value.date)
  slots.value = await slotService.getAvailableSlots(
    form.value.resources,
    dateValue
  )
}

const selectContact = async () => {
  // Use the native Bitrix CRM selector dialog.
  const items = await bitrix24Api.selectCRM(['contact', 'company'])
  const selected = items[0]
  if (selected) {
    form.value.leadName = selected.title
    const selectedId = Number(selected.id)
    form.value.clientId = Number.isNaN(selectedId) ? null : selectedId
  }
}

const save = async () => {
  saving.value = true
  try {
    const selectedSlot = slots.value.find(slot => slot.startTime === form.value.slot)
    if (!selectedSlot || !selectedSlot.available || form.value.resources.length === 0 || !form.value.date) {
      return
    }

    const dateFrom = `${form.value.date}T${selectedSlot.startTime}:00`
    const dateTo = `${form.value.date}T${selectedSlot.endTime}:00`
    const payload = {
      resourceIds: form.value.resources,
      resourceId: form.value.resources[0],
      dateFrom,
      dateTo,
      clientId: form.value.clientId ?? undefined
    }

    if (props.mode === 'create') {
      await bookingService.createBookingViaApi(payload)
    } else {
      await bookingService.updateBookingViaApi(props.bookingId!, payload)
    }
    await bitrix24Api.closeApplication()
  } finally {
    saving.value = false
  }
}
</script>

<template>
  <div v-if="loading" class="ui-alert ui-alert-warning" style="margin:16px;">
    Loading booking form…
  </div>

  <div v-else class="booking-form">
    <div class="ui-section ui-section-block ui-section-shadow">
      <div class="booking-form__header">
        <div class="ui-typography-heading-h2">{{ mode === 'create' ? 'Add Booking' : 'Edit Booking' }}</div>
        <div class="ui-typography-text-muted">Complete the details to reserve the selected resource.</div>
      </div>

      <div class="booking-form__body">
        <!-- Schedule -->
        <div class="ui-section ui-section-block">
          <div class="ui-typography-heading-h4">Schedule</div>
          <div class="booking-form__field">
            <div class="ui-typography-text-muted">Date</div>
            <div class="ui-ctl ui-ctl-textbox">
              <input type="date" class="ui-ctl-element" v-model="form.date" @change="loadSlots" />
            </div>
          </div>
        </div>

        <!-- Resources -->
        <div class="ui-section ui-section-block">
          <div class="ui-typography-heading-h4">Resources</div>
          <div class="ui-typography-text-muted">Choose one or more resources for this booking.</div>
          <div class="booking-form__resource-list">
            <label v-for="resource in resources" :key="resource.id" class="ui-ctl ui-ctl-checkbox booking-form__resource-item">
              <input
                class="ui-ctl-element"
                type="checkbox"
                :value="resource.id"
                v-model="form.resources"
                @change="loadSlots"
              />
              <span class="ui-ctl-label-text">{{ resource.name }}</span>
            </label>
          </div>
        </div>

        <!-- Slots -->
        <div class="ui-section ui-section-block">
          <div class="ui-typography-heading-h4">Available slots</div>
          <div class="booking-form__field">
            <div class="ui-typography-text-muted">Slots</div>
            <div class="ui-ctl ui-ctl-dropdown">
              <div class="ui-ctl-after ui-ctl-icon-angle"></div>
              <select class="ui-ctl-element" v-model="form.slot">
                <option value="" disabled>Select a slot</option>
                <option
                  v-for="s in slots"
                  :key="s.startTime"
                  :value="s.startTime"
                  :disabled="!s.available"
                >
                  {{ s.startTime }} - {{ s.endTime }}{{ s.available ? '' : ' (unavailable)' }}
                </option>
              </select>
            </div>
            <div class="ui-typography-text-muted" style="margin-top:6px;">
              Slots are available only when <b>all selected resources</b> are free.
            </div>
          </div>
        </div>

        <!-- Customer -->
        <div class="ui-section ui-section-block">
          <div class="ui-typography-heading-h4">Customer</div>
          <div class="booking-form__field">
            <div class="ui-typography-text-muted">Customer</div>
            <div class="ui-ctl ui-ctl-textbox">
              <input class="ui-ctl-element" v-model="form.leadName" placeholder="Customer name" />
            </div>
          </div>

          <button type="button" class="ui-btn ui-btn-primary ui-btn-round" @click="selectContact">
            + Add or select
          </button>

          <div class="booking-form__field" style="margin-top:12px;">
            <div class="ui-typography-text-muted">Phone</div>
            <div class="ui-ctl ui-ctl-textbox">
              <input class="ui-ctl-element" v-model="form.phone" placeholder="Phone" />
            </div>
          </div>

          <div class="booking-form__field">
            <div class="ui-typography-text-muted">Email</div>
            <div class="ui-ctl ui-ctl-textbox">
              <input class="ui-ctl-element" v-model="form.email" placeholder="Email" />
            </div>
          </div>
        </div>

        <!-- Other student ages -->
        <div class="ui-section ui-section-block">
          <div class="ui-typography-heading-h4">Other student ages</div>
          <div class="booking-form__ages">
            <div class="ui-ctl ui-ctl-textbox" v-for="(_, i) in form.ages" :key="i">
              <input class="ui-ctl-element" v-model="form.ages[i]" placeholder="Age" />
            </div>
          </div>
        </div>
      </div>

      <div class="booking-form__footer">
        <button class="ui-btn ui-btn-primary" :disabled="saving" @click="save">
          {{ saving ? 'Saving…' : 'Save booking' }}
        </button>
        <button class="ui-btn ui-btn-light-border" :disabled="saving" @click="bitrix24Api.closeApplication()">
          Cancel
        </button>
      </div>
    </div>
  </div>
</template>
