import "./assets/b24ui.css"; // B24UI styles (bundled, no CORS)

import { createApp } from "vue";
import App from "./App.vue";
import router from "./router";

// Keep only minimal, layout-focused overrides after B24UI
import "./styles/weekly-view.css";
import "./styles/booking-form.css";

// Optional debug hooks so you can call services from DevTools console:
//   __b24.bookingService.getWeeklyBookings(...)
import { bitrix24Api } from "./services/bitrix24Api";
import { bookingService } from "./services/bookingService";
import { resourceService } from "./services/resourceService";

const app = createApp(App);
app.use(router);
app.mount("#app");

(window as any).__b24 = { bitrix24Api, bookingService, resourceService };
