<script setup lang="ts">
import Market1Icon from '@bitrix24/b24icons-vue/main/Market1Icon'
</script>

<template>
  <Market1Icon />
</template>
