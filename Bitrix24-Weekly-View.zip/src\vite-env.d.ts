/// <reference types="vite/client" />

declare const BX: any;
declare const BX24: any;
